package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrbanclapClone1Application {

	public static void main(String[] args) {
		SpringApplication.run(UrbanclapClone1Application.class, args);
	}

}
